# Disable automatic Microsoft Store app updates

Stop the Microsoft Store from updating apps automatically.

| | |
|---|---|
| **Category** | windows-update |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | None |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\WindowsStore`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\WindowsStore]
"AutoDownload"=dword:00000002
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert windows-update/disable-store-auto-update`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\WindowsStore]
"AutoDownload"=-
```

## Notes

`2` = never auto-download. Apps will not receive security fixes until you update them manually.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
