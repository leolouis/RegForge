# No auto-restart while users are signed in

Prevent Windows Update from automatically restarting the PC while someone is signed in.

| | |
|---|---|
| **Category** | windows-update |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | None |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU]
"NoAutoRebootWithLoggedOnUsers"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert windows-update/no-auto-reboot-when-signed-in`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU]
"NoAutoRebootWithLoggedOnUsers"=-
```

## Notes

This is a Group Policy value. Settings may show "Some settings are managed by your organization". Updates still install; you just need to restart manually. Rollback deletes only this value.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
