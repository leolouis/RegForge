# Never combine taskbar buttons

Show a separate taskbar button for every window of the same app.

| | |
|---|---|
| **Category** | taskbar |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 (23H2 or later) |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"TaskbarGlomLevel"=dword:00000002
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert taskbar/never-combine-buttons`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"TaskbarGlomLevel"=dword:00000000
```

## Notes

`0` always combine (default), `1` when taskbar is full, `2` never.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
