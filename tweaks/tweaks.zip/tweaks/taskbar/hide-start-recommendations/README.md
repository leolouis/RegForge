# Hide Start menu recommendations (Windows 11)

Remove the Recommended section content from the Windows 11 Start menu.

| | |
|---|---|
| **Category** | taskbar |
| **Requires admin** | No |
| **Supported Windows** | Windows 11 (23H2 or later) |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"Start_IrisRecommendations"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert taskbar/hide-start-recommendations`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"Start_IrisRecommendations"=dword:00000001
```

## Notes

Behaviour varies between Windows 11 builds. Default is `1`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
