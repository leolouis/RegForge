# Hide the taskbar search box

Remove the search box or icon from the taskbar. Search still works from Start.

| | |
|---|---|
| **Category** | taskbar |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Takes effect immediately or after Explorer restart |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search]
"SearchboxTaskbarMode"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert taskbar/hide-search-box`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Search]
"SearchboxTaskbarMode"=-
```

## Notes

`0` hidden, `1` icon, `2` box, `3` icon and label. Rollback deletes the value because the default differs between Windows versions.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
