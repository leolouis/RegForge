# Align taskbar icons to the left (Windows 11)

Move the Windows 11 taskbar icons and Start button to the left edge.

| | |
|---|---|
| **Category** | taskbar |
| **Requires admin** | No |
| **Supported Windows** | Windows 11 |
| **Restart needed** | Takes effect immediately or after Explorer restart |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"TaskbarAl"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert taskbar/align-left`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"TaskbarAl"=dword:00000001
```

## Notes

`TaskbarAl`: 0 = left, 1 = center (default).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
