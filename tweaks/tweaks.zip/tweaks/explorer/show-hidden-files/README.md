# Show hidden files and folders

Show files and folders marked as hidden in File Explorer.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"Hidden"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/show-hidden-files`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"Hidden"=dword:00000002
```

## Notes

Windows default is `Hidden=2` (do not show). Protected operating system files remain hidden.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
