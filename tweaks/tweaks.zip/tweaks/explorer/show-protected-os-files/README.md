# Show protected operating system files

Reveal protected system files (such as desktop.ini and pagefile.sys) in Explorer.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Medium |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"ShowSuperHidden"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/show-protected-os-files`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"ShowSuperHidden"=dword:00000000
```

## Notes

Deleting or editing protected files can break Windows. Intended for viewing only. Default is `0`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
