# Show full path in the Explorer title bar

Display the complete folder path in the title bar of File Explorer windows.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | No |
| **Supported Windows** | Windows 10 |
| **Restart needed** | Reopen Explorer windows |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\CabinetState`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\CabinetState]
"FullPath"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/show-full-path-in-title-bar`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\CabinetState]
"FullPath"=-
```

## Notes

Mainly useful on Windows 10; Windows 11 Explorer has no title text. Rollback deletes the value so Windows uses its default.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
