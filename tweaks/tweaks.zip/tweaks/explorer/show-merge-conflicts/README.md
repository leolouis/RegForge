# Show folder merge conflicts

Ask what to do when copying folders with the same name instead of merging silently.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Open a new Explorer window |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"HideMergeConflicts"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/show-merge-conflicts`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"HideMergeConflicts"=dword:00000001
```

## Notes

Default is `1` (conflicts hidden, folders merged without prompting).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
