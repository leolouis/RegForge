# Open File Explorer to This PC

Open File Explorer on This PC instead of Home / Quick access.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Open a new Explorer window |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"LaunchTo"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/open-to-this-pc`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"LaunchTo"=-
```

## Notes

Rollback deletes the value so Windows falls back to its own default for your version.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
