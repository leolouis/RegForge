# Show empty drives

Show card reader and optical drive letters even when no media is inserted.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"HideDrivesWithNoMedia"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/show-empty-drives`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"HideDrivesWithNoMedia"=dword:00000001
```

## Notes

Default is `1` (empty drives hidden).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
