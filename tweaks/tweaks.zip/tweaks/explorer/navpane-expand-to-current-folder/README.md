# Navigation pane: show all folders and expand to current

Show all folders in the navigation pane and auto-expand to the folder you are viewing.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Open a new Explorer window |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"NavPaneShowAllFolders"=dword:00000001
"NavPaneExpandToCurrentFolder"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/navpane-expand-to-current-folder`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"NavPaneShowAllFolders"=dword:00000000
"NavPaneExpandToCurrentFolder"=dword:00000000
```

## Notes

Both values default to `0`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
