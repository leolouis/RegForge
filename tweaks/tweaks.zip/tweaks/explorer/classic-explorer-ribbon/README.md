# Classic Explorer ribbon (early Windows 11)

Block the new Windows 11 Explorer command bar so the older ribbon is used.

| | |
|---|---|
| **Category** | explorer |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 11 21H2 / early 22H2 builds only |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked]
"{e2bf9676-5f0f-44d9-bb81-2d3322345b7f}"=""
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert explorer/classic-explorer-ribbon`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Blocked]
"{e2bf9676-5f0f-44d9-bb81-2d3322345b7f}"=-
```

## Notes

Does nothing on current Windows 11 releases, where the old ribbon code has been removed. It works by blocking a shell extension for every user.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
