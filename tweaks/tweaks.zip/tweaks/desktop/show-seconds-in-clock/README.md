# Show seconds in the taskbar clock

Display seconds in the system tray clock.

| | |
|---|---|
| **Category** | desktop |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 (22H2 or later) |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"ShowSecondsInSystemClock"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert desktop/show-seconds-in-clock`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"ShowSecondsInSystemClock"=dword:00000000
```

## Notes

May slightly increase Explorer activity because the clock updates every second.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
