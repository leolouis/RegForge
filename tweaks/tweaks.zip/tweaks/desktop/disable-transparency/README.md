# Disable transparency effects

Turn off translucent effects on taskbar, Start and windows.

| | |
|---|---|
| **Category** | desktop |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Takes effect immediately |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize]
"EnableTransparency"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert desktop/disable-transparency`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize]
"EnableTransparency"=dword:00000001
```

## Notes

Mirrors Settings > Personalization > Colors > Transparency effects.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
