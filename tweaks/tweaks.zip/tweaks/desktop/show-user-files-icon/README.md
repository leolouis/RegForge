# Show your user folder on the desktop

Add your user files folder icon to the desktop.

| | |
|---|---|
| **Category** | desktop |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Refresh the desktop (F5) |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel]
"{59031a47-3f72-44a7-89c5-5595fe6b30ee}"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert desktop/show-user-files-icon`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel]
"{59031a47-3f72-44a7-89c5-5595fe6b30ee}"=dword:00000001
```

## Notes

`0` shows the icon, `1` hides it (default).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
