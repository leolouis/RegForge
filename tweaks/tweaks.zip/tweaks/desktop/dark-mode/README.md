# Dark mode for apps and system

Switch both the Windows UI and supporting apps to the dark theme.

| | |
|---|---|
| **Category** | desktop |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Takes effect immediately |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize]
"AppsUseLightTheme"=dword:00000000
"SystemUsesLightTheme"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert desktop/dark-mode`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize]
"AppsUseLightTheme"=dword:00000001
"SystemUsesLightTheme"=dword:00000001
```

## Notes

Rollback restores the light theme (`1`). If you used a custom mode, re-select it in Settings.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
