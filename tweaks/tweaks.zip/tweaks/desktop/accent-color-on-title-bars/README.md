# Accent colour on title bars

Use your accent colour on window title bars and borders.

| | |
|---|---|
| **Category** | desktop |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Takes effect immediately |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\DWM`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\DWM]
"ColorPrevalence"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert desktop/accent-color-on-title-bars`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\DWM]
"ColorPrevalence"=dword:00000000
```

## Notes

Default is `0`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
