# Disable Command Prompt

Block cmd.exe and batch files for the current user.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | High |

## What it changes

- `HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\System`

```reg
[HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\System]
"DisableCMD"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/disable-command-prompt`.

```reg
[HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\System]
"DisableCMD"=-
```

## Notes

This does NOT block PowerShell. `1` also stops batch files; `2` blocks only the interactive prompt. Many installers use batch files. Revert with `regforge.ps1 revert` or by importing `disable.reg`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
