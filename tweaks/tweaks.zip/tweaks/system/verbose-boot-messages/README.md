# Show verbose startup and shutdown messages

Show detailed status text (such as what Windows is doing) during sign-in, sign-out and shutdown.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System]
"VerboseStatus"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/verbose-boot-messages`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System]
"VerboseStatus"=-
```

## Notes

Useful for diagnosing slow boots. Rollback deletes the value.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
