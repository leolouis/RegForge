# Raise cached domain logons to 50

Remember up to 50 domain accounts for offline sign-in.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | None |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon]
"CachedLogonsCount"="50"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/increase-cached-logons`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon]
"CachedLogonsCount"="10"
```

## Notes

More cached credentials means more stored password verifiers an attacker could target. Only relevant on domain-joined PCs. Default is `10`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
