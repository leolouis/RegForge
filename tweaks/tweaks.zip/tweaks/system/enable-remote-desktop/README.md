# Enable Remote Desktop

Allow incoming Remote Desktop (RDP) connections.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10/11 Pro, Enterprise, Education |
| **Restart needed** | None |
| **Risk** | High |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server]
"fDenyTSConnections"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/enable-remote-desktop`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server]
"fDenyTSConnections"=dword:00000001
```

## Notes

Exposes the PC to RDP login attempts. Do not forward port 3389 to the internet; use a VPN. Keep Network Level Authentication on and use strong passwords. You may also need the Windows Firewall rule for Remote Desktop. Not available on Home.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
