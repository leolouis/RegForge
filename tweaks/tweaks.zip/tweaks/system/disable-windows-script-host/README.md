# Disable Windows Script Host

Block .vbs and .js scripts from running through wscript/cscript.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | None |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Script Host\Settings`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Script Host\Settings]
"Enabled"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/disable-windows-script-host`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows Script Host\Settings]
"Enabled"=-
```

## Notes

Some installers and logon scripts use WSH. PowerShell and batch files are not affected. Rollback deletes the value (enabled by default).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
