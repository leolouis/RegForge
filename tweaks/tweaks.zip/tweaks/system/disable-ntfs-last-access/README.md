# Disable NTFS last access time updates

Stop writing a last-accessed timestamp every time a file is read.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem]
"NtfsDisableLastAccessUpdate"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/disable-ntfs-last-access`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem]
"NtfsDisableLastAccessUpdate"=dword:80000002
```

## Notes

Some backup, indexing and cleanup tools rely on last-access times. Rollback writes the Windows default `0x80000002` (system managed).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
