# Block USB mass storage devices

Prevent USB flash drives and external disks from mounting.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot (or reconnect devices) |
| **Risk** | High |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR]
"Start"=dword:00000004
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/block-usb-storage`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\USBSTOR]
"Start"=dword:00000003
```

## Notes

Blocks every USB storage device, including backup drives. Rollback restores the default `3` (load on demand). Intended for lockdown scenarios.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
