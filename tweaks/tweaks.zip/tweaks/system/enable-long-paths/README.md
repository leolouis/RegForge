# Enable Win32 long paths

Allow applications that opt in to use file paths longer than 260 characters.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10 (1607+), Windows 11 |
| **Restart needed** | Reboot recommended |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem]
"LongPathsEnabled"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/enable-long-paths`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem]
"LongPathsEnabled"=dword:00000000
```

## Notes

Only applications that declare long path support in their manifest benefit. File Explorer itself still has limits.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
