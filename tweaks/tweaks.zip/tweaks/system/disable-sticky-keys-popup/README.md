# Disable Sticky/Filter/Toggle Keys shortcuts

Stop the pop-ups triggered by pressing Shift five times, holding Shift, or holding Num Lock.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Control Panel\Accessibility\StickyKeys`
- `HKEY_CURRENT_USER\Control Panel\Accessibility\Keyboard Response`
- `HKEY_CURRENT_USER\Control Panel\Accessibility\ToggleKeys`

```reg
[HKEY_CURRENT_USER\Control Panel\Accessibility\StickyKeys]
"Flags"="506"

[HKEY_CURRENT_USER\Control Panel\Accessibility\Keyboard Response]
"Flags"="122"

[HKEY_CURRENT_USER\Control Panel\Accessibility\ToggleKeys]
"Flags"="58"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/disable-sticky-keys-popup`.

```reg
[HKEY_CURRENT_USER\Control Panel\Accessibility\StickyKeys]
"Flags"="510"

[HKEY_CURRENT_USER\Control Panel\Accessibility\Keyboard Response]
"Flags"="126"

[HKEY_CURRENT_USER\Control Panel\Accessibility\ToggleKeys]
"Flags"="62"
```

## Notes

Rollback writes the Windows default flag values (510, 126, 62). The features can still be turned on in Settings > Accessibility.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
