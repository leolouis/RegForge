# Increase NTFS MFT zone reservation

Reserve more disk space for the Master File Table (12.5 % to 25 %).

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem]
"NtfsMftZoneReservation"=dword:00000002
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/ntfs-mft-zone-reservation`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\FileSystem]
"NtfsMftZoneReservation"=dword:00000001
```

## Notes

Only helps volumes that will hold very large numbers of small files. Costs some free space for large files. Default is `1`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
