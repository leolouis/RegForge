# Delete roaming profile cache at sign-out

Remove locally cached copies of roaming profiles when the user signs out.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System]
"DeleteRoamingCache"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/delete-roaming-profile-cache`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System]
"DeleteRoamingCache"=-
```

## Notes

Only relevant on domain machines with roaming profiles. Sign-in takes longer because the profile is downloaded again.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
