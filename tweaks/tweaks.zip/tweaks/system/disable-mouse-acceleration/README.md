# Disable mouse pointer acceleration

Turn off Enhance pointer precision for consistent 1:1 mouse movement, popular for gaming.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Control Panel\Mouse`

```reg
[HKEY_CURRENT_USER\Control Panel\Mouse]
"MouseSpeed"="0"
"MouseThreshold1"="0"
"MouseThreshold2"="0"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/disable-mouse-acceleration`.

```reg
[HKEY_CURRENT_USER\Control Panel\Mouse]
"MouseSpeed"="1"
"MouseThreshold1"="6"
"MouseThreshold2"="10"
```

## Notes

Rollback writes the documented defaults (1, 6, 10). Same as unticking Enhance pointer precision.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
