# Block SmartScreen warning bypass

Enforce SmartScreen and remove the option to run flagged files anyway.

| | |
|---|---|
| **Category** | system |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | Reboot recommended |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System]
"EnableSmartScreen"=dword:00000001
"ShellSmartScreenLevel"="Block"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert system/smartscreen-block-bypass`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System]
"EnableSmartScreen"=-
"ShellSmartScreenLevel"=-
```

## Notes

`ShellSmartScreenLevel` has no effect without `EnableSmartScreen=1`, so both are set. Legitimate unsigned tools may become unrunnable. Rollback deletes both values.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
