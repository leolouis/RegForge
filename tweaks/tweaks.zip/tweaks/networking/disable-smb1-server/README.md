# Disable the SMB1 server protocol

Prevent this PC from serving files over the obsolete, insecure SMB1 protocol.

| | |
|---|---|
| **Category** | networking |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot recommended |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters]
"SMB1"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert networking/disable-smb1-server`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters]
"SMB1"=-
```

## Notes

Very old NAS devices and scanners may stop connecting. If the value already existed before you applied this, restore it from the backup made by `regforge.ps1`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
