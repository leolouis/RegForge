# Disable multimedia network throttling

Set the MMCSS NetworkThrottlingIndex to unlimited.

| | |
|---|---|
| **Category** | networking |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile]
"NetworkThrottlingIndex"=dword:ffffffff
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert networking/disable-network-throttling`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile]
"NetworkThrottlingIndex"=dword:0000000a
```

## Notes

Widely recommended for gaming, but measurable benefit on current Windows is unproven and some users report worse network latency. Default is `10`. Try it and keep it only if you see a real difference.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
