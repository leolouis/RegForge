# Disable LLMNR

Turn off Link-Local Multicast Name Resolution, a legacy protocol often abused in spoofing attacks.

| | |
|---|---|
| **Category** | networking |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | Reboot recommended |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient]
"EnableMulticast"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert networking/disable-llmnr`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient]
"EnableMulticast"=-
```

## Notes

May affect name resolution of devices on small networks without DNS (use their IP address or hosts file). Rollback deletes the value.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
