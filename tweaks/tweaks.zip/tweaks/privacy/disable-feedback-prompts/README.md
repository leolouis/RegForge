# Disable Windows feedback prompts

Stop Windows from asking for feedback.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | None |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Siuf\Rules`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Siuf\Rules]
"NumberOfSIUFInPeriod"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-feedback-prompts`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Siuf\Rules]
"NumberOfSIUFInPeriod"=-
```

## Notes

Rollback deletes the value. The empty `Rules` key is left in place, which is harmless.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
