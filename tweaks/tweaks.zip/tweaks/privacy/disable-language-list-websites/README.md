# Stop websites accessing your language list

Prevent websites from reading your installed language list.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | None |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Control Panel\International\User Profile`

```reg
[HKEY_CURRENT_USER\Control Panel\International\User Profile]
"HttpAcceptLanguageOptOut"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-language-list-websites`.

```reg
[HKEY_CURRENT_USER\Control Panel\International\User Profile]
"HttpAcceptLanguageOptOut"=-
```

## Notes

Rollback deletes the value (not present by default).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
