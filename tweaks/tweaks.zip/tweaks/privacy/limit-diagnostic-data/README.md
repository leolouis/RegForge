# Limit diagnostic data to required

Set diagnostic data to the minimum that Windows allows on your edition.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | None |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection]
"AllowTelemetry"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/limit-diagnostic-data`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\DataCollection]
"AllowTelemetry"=-
```

## Notes

Value `1` is Required (Basic) on every edition; `0` is honoured only on Enterprise/Education, so it is not used here.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
