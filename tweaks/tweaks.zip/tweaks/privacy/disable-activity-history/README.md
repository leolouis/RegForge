# Disable activity history

Stop Windows collecting and uploading your activity history (Timeline).

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 (Pro, Enterprise, Education) |
| **Restart needed** | Reboot recommended |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System]
"EnableActivityFeed"=dword:00000000
"PublishUserActivities"=dword:00000000
"UploadUserActivities"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-activity-history`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\System]
"EnableActivityFeed"=-
"PublishUserActivities"=-
"UploadUserActivities"=-
```

## Notes

Group Policy values. Settings may show "managed by your organization". Rollback deletes the values.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
