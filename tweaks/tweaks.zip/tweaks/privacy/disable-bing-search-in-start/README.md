# Disable web results in Start search

Keep Start search local: no Bing web suggestions.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Restart Explorer or sign out |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Explorer`

```reg
[HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Explorer]
"DisableSearchBoxSuggestions"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-bing-search-in-start`.

```reg
[HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\Explorer]
"DisableSearchBoxSuggestions"=-
```

## Notes

Uses a per-user policy value. Rollback deletes it.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
