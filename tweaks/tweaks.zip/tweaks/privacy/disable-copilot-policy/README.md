# Turn off Windows Copilot (policy)

Disable the original Windows Copilot integration for the current user.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | No |
| **Supported Windows** | Windows 11 (builds with the legacy Copilot sidebar) |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\WindowsCopilot`

```reg
[HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\WindowsCopilot]
"TurnOffWindowsCopilot"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-copilot-policy`.

```reg
[HKEY_CURRENT_USER\Software\Policies\Microsoft\Windows\WindowsCopilot]
"TurnOffWindowsCopilot"=-
```

## Notes

Microsoft has since replaced the sidebar with the Copilot app, which this policy does not remove. On newer builds, uninstall the app instead.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
