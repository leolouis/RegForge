# Disable app launch tracking

Stop Windows tracking launched apps to improve Start and search results.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"Start_TrackProgs"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-app-launch-tracking`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced]
"Start_TrackProgs"=dword:00000001
```

## Notes

Mirrors Settings > Privacy > General > Let Windows improve Start and search results by tracking app launches.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
