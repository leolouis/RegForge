# Disable advertising ID

Stop apps from using your advertising ID for cross-app personalised ads.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | None |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo]
"Enabled"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-advertising-id`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo]
"Enabled"=dword:00000001
```

## Notes

Mirrors Settings > Privacy & security > General > Let apps show me personalized ads. You will still see ads, just less relevant ones.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
