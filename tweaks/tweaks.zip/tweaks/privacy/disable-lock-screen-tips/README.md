# Disable lock screen tips and spotlight overlays

Remove fun facts, tips and promotional overlays from the lock screen.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Lock and unlock |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager]
"RotatingLockScreenOverlayEnabled"=dword:00000000
"SubscribedContent-338387Enabled"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-lock-screen-tips`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager]
"RotatingLockScreenOverlayEnabled"=dword:00000001
"SubscribedContent-338387Enabled"=dword:00000001
```

## Notes

Defaults are `1`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
