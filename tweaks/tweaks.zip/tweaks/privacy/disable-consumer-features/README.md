# Disable Windows consumer features

Stop Windows installing suggested third-party apps and promotions automatically.

| | |
|---|---|
| **Category** | privacy |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10/11 Enterprise and Education |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CloudContent`

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CloudContent]
"DisableWindowsConsumerFeatures"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert privacy/disable-consumer-features`.

```reg
[HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CloudContent]
"DisableWindowsConsumerFeatures"=-
```

## Notes

Microsoft only honours this on Enterprise and Education editions; it is ignored on Home and Pro.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
