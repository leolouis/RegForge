# Faster menu show delay

Reduce the delay before cascading menus open from 400 ms to 100 ms.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Control Panel\Desktop`

```reg
[HKEY_CURRENT_USER\Control Panel\Desktop]
"MenuShowDelay"="100"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/faster-menu-show-delay`.

```reg
[HKEY_CURRENT_USER\Control Panel\Desktop]
"MenuShowDelay"="400"
```

## Notes

`MenuShowDelay` is a string value in milliseconds. The default is `400`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
