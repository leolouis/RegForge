# Disable Game DVR background capture

Turn off Xbox Game Bar background recording, which can cost performance in games.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\System\GameConfigStore`
- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\GameDVR`

```reg
[HKEY_CURRENT_USER\System\GameConfigStore]
"GameDVR_Enabled"=dword:00000000

[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\GameDVR]
"AppCaptureEnabled"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/disable-game-dvr`.

```reg
[HKEY_CURRENT_USER\System\GameConfigStore]
"GameDVR_Enabled"=dword:00000001

[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\GameDVR]
"AppCaptureEnabled"=dword:00000001
```

## Notes

Game Bar clip capture stops working until rolled back. Defaults are `1`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
