# Enable hardware-accelerated GPU scheduling

Let the GPU manage its own video memory scheduling to reduce latency.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10 (2004+), Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\GraphicsDrivers`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\GraphicsDrivers]
"HwSchMode"=dword:00000002
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/enable-hardware-gpu-scheduling`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\GraphicsDrivers]
"HwSchMode"=-
```

## Notes

Needs a supported GPU and recent driver; `2` = on, `1` = off. Rollback deletes the value so Windows picks its default for your hardware. You can also toggle it in Settings > System > Display > Graphics.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
