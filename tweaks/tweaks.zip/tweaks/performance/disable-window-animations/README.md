# Disable minimise/maximise animation

Skip the window minimise and maximise animation.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Control Panel\Desktop\WindowMetrics`

```reg
[HKEY_CURRENT_USER\Control Panel\Desktop\WindowMetrics]
"MinAnimate"="0"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/disable-window-animations`.

```reg
[HKEY_CURRENT_USER\Control Panel\Desktop\WindowMetrics]
"MinAnimate"="1"
```

## Notes

`MinAnimate` is a string value. Default is `1`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
