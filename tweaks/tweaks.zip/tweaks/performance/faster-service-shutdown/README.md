# Faster service shutdown timeout

Shorten how long Windows waits for services to stop at shutdown (5 s to 2 s).

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control]
"WaitToKillServiceTimeout"="2000"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/faster-service-shutdown`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control]
"WaitToKillServiceTimeout"="5000"
```

## Notes

Services that need longer to flush data (databases, backup software) may be terminated early. Default is `5000` ms.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
