# Remove desktop app startup delay

Start startup apps immediately after sign-in instead of after a built-in delay.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Low |

## What it changes

- `HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize`

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize]
"StartupDelayInMSec"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/disable-startup-delay`.

```reg
[HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize]
"StartupDelayInMSec"=-
```

## Notes

Rollback deletes the value (not present by default). Many startup apps at once can make sign-in feel slower.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
