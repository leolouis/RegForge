# Expose the CPU core parking power setting

Make the hidden Minimum processor cores (core parking) option visible in Advanced power settings.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reopen power options |
| **Risk** | Low |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4615-815a-8deb0ecc35e2`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4615-815a-8deb0ecc35e2]
"Attributes"=dword:00000000
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/show-core-parking-option`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Power\PowerSettings\54533251-82be-4824-96c1-47b60b740d00\0cc5b647-c1df-4615-815a-8deb0ecc35e2]
"Attributes"=dword:00000001
```

## Notes

This only unhides the setting; it does not change core parking itself. After applying, open Control Panel > Power Options > Change plan settings > Advanced > Processor power management and adjust it. Default is `1` (hidden).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
