# Keep the kernel in RAM (disable paging executive)

Stop Windows paging kernel and driver code out to disk.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management]
"DisablePagingExecutive"=dword:00000001
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/disable-paging-executive`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management]
"DisablePagingExecutive"=dword:00000000
```

## Notes

Only sensible with plenty of RAM (16 GB or more). On low-memory systems it can make things slower. Default is `0`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
