# Favour foreground applications for CPU time

Change Win32PrioritySeparation so the active window gets a larger share of CPU scheduling.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | Yes |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Reboot |
| **Risk** | Medium |

## What it changes

- `HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\PriorityControl`

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\PriorityControl]
"Win32PrioritySeparation"=dword:0000001a
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/foreground-priority-boost`.

```reg
[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\PriorityControl]
"Win32PrioritySeparation"=dword:00000002
```

## Notes

`0x1a` = short, fixed quantum with the strongest foreground boost. Background tasks (renders, downloads) may run slower. Default on client Windows is `2`.

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
