# Faster app shutdown timeouts

Shorten the time Windows waits for apps to close before ending them at sign-out or shutdown.

| | |
|---|---|
| **Category** | performance |
| **Requires admin** | No |
| **Supported Windows** | Windows 10, Windows 11 |
| **Restart needed** | Sign out and back in |
| **Risk** | Medium |

## What it changes

- `HKEY_CURRENT_USER\Control Panel\Desktop`

```reg
[HKEY_CURRENT_USER\Control Panel\Desktop]
"WaitToKillAppTimeout"="5000"
"HungAppTimeout"="3000"
```

## Rollback

Run `disable.reg`, or `.\regforge.ps1 revert performance/faster-app-shutdown`.

```reg
[HKEY_CURRENT_USER\Control Panel\Desktop]
"WaitToKillAppTimeout"="20000"
"HungAppTimeout"="5000"
```

## Notes

Apps that need longer to save data may be ended early and lose unsaved work. Rollback writes the documented defaults (20000 and 5000 ms).

## Testing

No verified test reports yet. If you tried this on a real machine, add an entry to `tested` in `tweak.json` (see CONTRIBUTING.md).
